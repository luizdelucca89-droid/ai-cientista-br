# Declaração de Uso de IA e Reprodutibilidade

## Uso de IA
- **Sistema:** AI Cientista BR — pipeline multiagente com roteador MoE.
- **Tarefas:** mineração de SOTA, geração de hipótese, código do experimento,
  redação (IMRaD/LaTeX), revisão e checagem de fidelidade numérica.
- **Modelos:** roteamento por tarefa (`config.modelos.json`): raciocínio
  (Nemotron/Gemini), redação (Gemini/GLM/Mistral), código (Codestral),
  alto volume (Ministral), multimodal (Nemotron-VL/Gemini), validação cruzada
  (LFM/GLM/GPT-OSS). Coringa: Gemini.
- **Papel do humano:** definição do tema e da hipótese, curadoria das fontes,
  validação dos resultados e decisão de reportar o resultado nulo.

## Reprodutibilidade
- **Seed:** 42 (numpy, scikit-learn).
- **Validação:** temporal (TimeSeriesSplit expansivo + holdout cronológico).
- **Ambiente:** Python 3.13.15 (Linux x86_64).
- **Custo:** R$ 0,00 — apenas APIs e dados públicos abertos.
- **Comando:** `python experimentos/dengue_ndvi.py` (ou `--offline` com cache).

## Integridade
- **Zero dados sintéticos:** todas as observações vêm de InfoDengue, NASA GIBS
  e IBGE. Fontes indisponíveis falham explicitamente; nada é gerado no lugar.
- **Portão de fidelidade numérica:** todo número do manuscrito é injetado dos
  artefatos JSON do experimento. A checagem reporta 0 números sem lastro.
- **Citações:** cada `\cite` referencia um DOI real verificado no Crossref;
  nenhum DOI é inventado.

## Ética
- Dados públicos e agregados por município/semana (sem dados pessoais).
- Conformidade com as políticas de uso das fontes públicas brasileiras.
- O manuscrito declara abertamente que foi gerado por IA com curadoria humana.

## Resultado
- Decisão sobre a hipótese: **não rejeitar H0 (resultado nulo)**
- ΔF1 (B vs A) = +0.0177; ΔF1 satélite isolado (B vs C)
  = +0.0049.
